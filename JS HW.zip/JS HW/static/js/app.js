// from data.js
var tableData = data;

// YOUR CODE HERE!
$("#jugar2").hide();
$("#jugar").show();

function Refresh(){
	
	location.reload();
	//$("#tablebody tr").empty();
	$("#jugar2").hide();
			
}

function myFunction() {
	
            $("#jugar").hide();
			$("#jugar2").show();
        
	var selectfilter = document.getElementById("sf").value;
	
	var gdate = document.getElementById("datetime").value;
	
	var result=gdate;
 
	
	if(selectfilter=="datetime" ){
		
for (var i=0; i<=tableData.length; i++)
{
	
	
if (tableData[i].datetime == gdate) {
	
	//document.getElementById('tablebody').innerHTML= "<tr>";
	document.getElementById('demo').innerHTML+= '<p>'+ tableData[i].datetime+'</p><br><br>';
	document.getElementById('demo1').innerHTML+= '<p>'+ tableData[i].city+'</p><br><br>';
	document.getElementById('demo2').innerHTML+= '<p>'+ tableData[i].state+'</p><br><br>';
	document.getElementById('demo3').innerHTML+= '<p>'+ tableData[i].country+'</p><br><br>';
	document.getElementById('demo4').innerHTML+= '<p>'+ tableData[i].shape+'</p><br><br>';
	document.getElementById('demo5').innerHTML+= '<p>'+ tableData[i].durationMinutes+'</p><br><br>';
	document.getElementById('demo6').innerHTML+= '<p>'+ tableData[i].comments+'</p><br><br>';
	//document.getElementById('tablebody').innerHTML= "</tr>";
	 
	
	}

}


}


	else if(selectfilter=="city" ){
for (var i=0; i<=tableData.length; i++)
{
	
	
if (tableData[i].city == gdate) {
		document.getElementById('demo').innerHTML+= '<p>'+ tableData[i].datetime+'</p><br><br>';
	document.getElementById('demo1').innerHTML+= '<p>'+ tableData[i].city+'</p><br><br>';
	document.getElementById('demo2').innerHTML+= '<p>'+ tableData[i].state+'</p><br><br>';
	document.getElementById('demo3').innerHTML+= '<p>'+ tableData[i].country+'</p><br><br>';
	document.getElementById('demo4').innerHTML+= '<p>'+ tableData[i].shape+'</p><br><br>';
	document.getElementById('demo5').innerHTML+= '<p>'+ tableData[i].durationMinutes+'</p><br><br>';
	document.getElementById('demo6').innerHTML+= '<p>'+ tableData[i].comments+'</p><br>';
	
	
	}
}}


	else if(selectfilter=="state" ){
for (var i=0; i<=tableData.length; i++)
{
	
	
if (tableData[i].state == gdate) {
		document.getElementById('demo').innerHTML+= '<p>'+ tableData[i].datetime+'</p><br><br>';
	document.getElementById('demo1').innerHTML+= '<p>'+ tableData[i].city+'</p><br><br>';
	document.getElementById('demo2').innerHTML+= '<p>'+ tableData[i].state+'</p><br><br>';
	document.getElementById('demo3').innerHTML+= '<p>'+ tableData[i].country+'</p><br><br>';
	document.getElementById('demo4').innerHTML+= '<p>'+ tableData[i].shape+'</p><br><br>';
	document.getElementById('demo5').innerHTML+= '<p>'+ tableData[i].durationMinutes+'</p><br><br>';
	document.getElementById('demo6').innerHTML+= '<p>'+ tableData[i].comments+'</p><br><br>';
	
	
	}
}}

	else if(selectfilter=="country" ){
for (var i=0; i<=tableData.length; i++)
{
	
	
if (tableData[i].country == gdate) {
		document.getElementById('demo').innerHTML+= '<p>'+ tableData[i].datetime+'</p><br><br>';
	document.getElementById('demo1').innerHTML+= '<p>'+ tableData[i].city+'</p><br><br>';
	document.getElementById('demo2').innerHTML+= '<p>'+ tableData[i].state+'</p><br><br>';
	document.getElementById('demo3').innerHTML+= '<p>'+ tableData[i].country+'</p><br><br>';
	document.getElementById('demo4').innerHTML+= '<p>'+ tableData[i].shape+'</p><br><br>';
	document.getElementById('demo5').innerHTML+= '<p>'+ tableData[i].durationMinutes+'</p><br><br>';
	document.getElementById('demo6').innerHTML+= '<p>'+ tableData[i].comments+'</p><br><br>';
		
	
	
	}
}}

	else if(selectfilter=="shape" ){
for (var i=0; i<=tableData.length; i++)
{
	
	
if (tableData[i].shape == gdate) {
		document.getElementById('demo').innerHTML+= '<p>'+ tableData[i].datetime+'</p><br><br>';
	document.getElementById('demo1').innerHTML+= '<p>'+ tableData[i].city+'</p><br><br>';
	document.getElementById('demo2').innerHTML+= '<p>'+ tableData[i].state+'</p><br><br>';
	document.getElementById('demo3').innerHTML+= '<p>'+ tableData[i].country+'</p><br><br>';
	document.getElementById('demo4').innerHTML+= '<p>'+ tableData[i].shape+'</p><br><br>';
	document.getElementById('demo5').innerHTML+= '<p>'+ tableData[i].durationMinutes+'</p><br><br>';
	document.getElementById('demo6').innerHTML+= '<p>'+ tableData[i].comments+'</p><br><br>';
		
	
	
	}
}}
else if(selectfilter=="select" ){
	document.getElementById('sdiv').innerHTML= "<h3>Please Select some filter</h3>";
}


}




